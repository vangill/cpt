=== 1.2.8 ==
- [BUG] Fix customizer style

=== 1.2.7 ==
- [BUG] Fix console error in wp 5.8 on gutenberg editor

=== 1.2.6 ==
- [BUG] Fix sanitize data

=== 1.2.5 ==
- [BUG] Fix slider input issue

=== 1.2.4 ==
- [BUG] Fix font-family style generator
- [BUG] Fix empty style option style generator

=== 1.2.3 ==
- [BUG] Fix customizer mixed content issue

=== 1.2.2 ==
- [BUG] Fix issue with implode() function PHP 7.4

=== 1.2.1 ==
- fix refresh issue on customizer previewer

=== 1.2.0 ==
- Minor css fix for wrong loader position
- Add Redirect Tag functionality

=== 1.1.0 ==
- [NEW FEATURE] New ajax control
- [IMPROVEMENT] Include style generator for get option
- [BUG] Fix bug some CSS not rendered correctly on Customizer
- [BUG] Fix cannot redeclare certain function issue
- [BUG] Fix can't edit widgets cause by parsing error

=== 1.0.0 ===
- This customizer plugin is fork of Kirki (https://github.com/aristath/kirki) to extend its ability :
- Better handling for active callback (active callback not depend on page refresh)
- Style Generator for Customizer Control
- Redirect page when control changed

