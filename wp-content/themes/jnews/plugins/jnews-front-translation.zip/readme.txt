Change Log :

== 10.0.1 ==
- [IMPROVEMENT] Add Twitch social author

== 10.0.0 ==
- [IMPROVEMENT] Compatible with JNews v10.0.0

== 9.0.3 ==
- [BUG] Fix missing translation for paywall and podcast

== 9.0.2 ==
- [BUG] Fix PHP 5.6 issue
- [BUG] Fix error message when WordPress checks for latest theme or plugin versions.

== 9.0.1 ==
- [IMPROVEMENT] Add new translation string

== 9.0.0 ==
- [IMPROVEMENT] Compatible with JNews v9.0.0
- [IMPROVEMENT] Add string translation for JNews - Bookmark

== 8.0.1 ==
- [IMPROVEMENT] Add new translation string

== 8.0.0 ==
- [IMPROVEMENT] Compatible with JNews v8.0.0

== 7.0.6 ==
- [IMPROVEMENT] Add frontend translation for subscribe download

== 7.0.5 ==
- [BUG] Fix missing translation on Paywall popup login

== 7.0.4 ==
- [BUG] Fix missing translation on zoom button

== 7.0.3 ==
- [BUG] Fix missing translation on JNews account pop-up

== 7.0.2 ==
- [BUG] Fix empty value on Frontend Translation

== 7.0.1 ==
- [BUG] FIX String translation

== 7.0.0 ==
- [IMPROVEMENT] Compatible with JNews v7.0.0
- [IMPROVEMENT] Add string translation for plural social text

== 6.0.1 ==
- [IMPROVEMENT] Add string translation for integration co author feature

== 6.0.0 ==
- [IMPROVEMENT] Compatible with JNews v6.0.0

== 5.0.0 ==
- [IMPROVEMENT] Compatible with JNews v5.0.0

== 4.0.1 ==
- [IMPROVEMENT] Add frontend translation for user website field

== 4.0.0 ==
- [IMPROVEMENT] Compatible with JNews v4.0.0

== 3.0.2 ==
- [IMPROVEMENT] Update comment label

== 3.0.1 ==
- [IMPROVEMENT] Update comment label

== 3.0.0 ==
- [IMPROVEMENT] Compatible with JNews v3.0.0

== 2.0.3 ==
- [BUG] Fix get plugin data issue

== 2.0.2 ==
- [IMPROVEMENT] Add frontend string translation for account page
- [BUG] Fix version issue on frontend translation dashboard

== 2.0.1 ==
- [IMPROVEMENT] Add frontend translation mobile truncate

== 2.0.0 ==
- [IMPROVEMENT] Compatible with JNews v2.0.0

== 1.0.4 ==
- [IMPROVEMENT] Add string translation for Telegram social icon

== 1.0.3 ==
- [IMPROVEMENT] Add string translation for StumbleUpon social icon

== 1.0.2 ==
- [IMPROVEMENT] Add string translation for Hatena share button

== 1.0.1 ==
- [BUG] Fix issue on front-end translation

== 1.0.0 ==
- First Release
