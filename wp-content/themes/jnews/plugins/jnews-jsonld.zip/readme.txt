Change Log :

== 10.0.2 ==
- [BUG] Fix JSON LD brand

== 10.0.1 ==
- [IMPROVEMENT] Add Twitch social author

== 10.0.0 ==
- [IMPROVEMENT] Compatible with JNews v10.0.0

== 9.0.0 ==
- [IMPROVEMENT] Compatible with JNews v9.0.0

== 8.0.0 ==
- [IMPROVEMENT] Compatible with JNews v8.0.0

== 7.0.3 ==
- [BUG] Fix encoding JSON LD

== 7.0.2 ==
- [IMPROVEMENT] Update some structured data

== 7.0.1 ==
- [BUG] Fix invalid json output

== 7.0.0 ==
- [IMPROVEMENT] Compatible with JNews v7.0.0

== 6.0.0 ==
- [IMPROVEMENT] Compatible with JNews v6.0.0

== 5.0.2 ==
- [IMPROVEMENT] Update Google Structured Data

== 5.0.1 ==
- [IMPROVEMENT] Compatible with new Google Structured Data

== 5.0.0 ==
- [IMPROVEMENT] Compatible with JNews v5.0.0

== 4.0.0 ==
- [IMPROVEMENT] Compatible with JNews v4.0.0

== 3.0.0 ==
- [IMPROVEMENT] Compatible with JNews v3.0.0

== 2.0.0 ==
- [IMPROVEMENT] Compatible with JNews v2.0.0

== 1.0.0 ==
- First Release
