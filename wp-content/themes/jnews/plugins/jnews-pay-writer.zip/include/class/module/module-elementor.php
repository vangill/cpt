<?php
/**
 * @author Jegtheme
 */

/**
 * Class JNews_Element_Donation_Elementor
 */
class JNews_Element_Donation_Elementor extends \JNews\Elementor\ModuleElementorAbstract {
}
