<?php

class JNews_Element_Donation_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {
}
