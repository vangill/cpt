<?php
/**
 * @author Jegtheme
 */

return array(
	array(
		'name'   => 'JNews_Element_Donation',
		'alias'  => 'donation_element',
		'type'   => 'block',
		'image'  => '',
		'widget' => true,
		'view'   => 'include/class/element/class-jnews-element-donation-view.php',
		'option' => 'include/class/element/class-jnews-element-donation-option.php',
	),
);
