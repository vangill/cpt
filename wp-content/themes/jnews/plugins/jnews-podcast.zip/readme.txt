Change Log :

== 10.0.3 ==
- [IMPROVEMENT] Better view counter query optimization

== 10.0.2 ==
- [BUG] Fix product image disappear when use JNews - Podcast plugin

== 10.0.1 ==
- [BUG] Fix excerpt showing shortcode

== 10.0.0 ==
- [IMPROVEMENT] Compatible with JNews v10.0.0

== 9.0.4 ==
- [BUG] Fix missing translation

== 9.0.3 ==
- [BUG] Fix missing translation
- [BUG] Fix media button responsiveness on podcast block 2

== 9.0.2 ==
- [BUG] Fix share position in media menu section

== 9.0.1 ==
- [BUG] Fix podcast play button issue

== 9.0.0 ==
- [IMPROVEMENT] Compatible with JNews v9.0.0

== 8.0.3 ==
- [IMPROVEMENT] Update series counter
- [BUG] Fix PHP 5.6 issue

== 8.0.2 ==
- [BUG] Fix sanitize data

== 8.0.1 ==
- [BUG] Fix Podcast block shortcode issue

== 8.0.0 ==
- First Release
