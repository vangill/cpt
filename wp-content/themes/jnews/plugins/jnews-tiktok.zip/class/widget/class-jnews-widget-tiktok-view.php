<?php

namespace JNews\Module\Widget;

use JNews\Module\Widget\WidgetViewAbstract;

/**
 * JNews Tiktok Element
 *
 * @author Jegtheme
 * @since 1.0.0
 * @package jnews-tiktok
 */
class Widget_Tiktok_View extends WidgetViewAbstract {
}
