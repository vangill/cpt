<?php
/*
	Plugin Name: JNews - Webstories
	Plugin URI: http://jegtheme.com/
	Description: Webstories element for wordpress
	Version: 10.0.1
	Author: Jegtheme
	Author URI: http://jegtheme.com
	License: GPL2
	Text Domain: jnews-webstories
*/

defined( 'JNEWS_WEBSTORIES' ) || define( 'JNEWS_WEBSTORIES', 'jnews-webstories' );
defined( 'JNEWS_WEBSTORIES_VERSION' ) || define( 'JNEWS_WEBSTORIES_VERSION', '10.0.1' );
defined( 'JNEWS_WEBSTORIES_URL' ) || define( 'JNEWS_WEBSTORIES_URL', plugins_url( JNEWS_WEBSTORIES ) );
defined( 'JNEWS_WEBSTORIES_FILE' ) || define( 'JNEWS_WEBSTORIES_FILE', __FILE__ );
defined( 'JNEWS_WEBSTORIES_DIR' ) || define( 'JNEWS_WEBSTORIES_DIR', plugin_dir_path( __FILE__ ) );
defined( 'JNEWS_WEBSTORIES_CLASSPATH' ) || define( 'JNEWS_WEBSTORIES_CLASSPATH', JNEWS_WEBSTORIES_DIR . 'include/class/' );

require_once JNEWS_WEBSTORIES_DIR . 'include/autoload.php';

/**
 * Initialise JNews Webstories
 *
 * @return JNews\Webstory\Init
 */
function JNews_Webstory() {
	static $instance;

	// first call to instance() initializes the plugin!
	if ( null === $instance || ! ( $instance instanceof JNews\WEBSTORIES\Init ) ) {
		$instance = JNews\WEBSTORIES\Init::instance();
	}

	return $instance;
}

JNews_Webstory();
