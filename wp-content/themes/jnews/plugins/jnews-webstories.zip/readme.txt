Change Log :

== 10.0.1 ==
- optimize ajax request

== 10.0.0 ==
- First Release